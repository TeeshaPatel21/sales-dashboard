import streamlit as st
import pandas as pd
import plotly.express as px

st.title("Sales Dashboard")
st.markdown("This is a simple interactive sales dashboard.")

# Load data
df = pd.read_csv("sales_data.csv")

# Filters
region = st.selectbox("Select Region", options=["All"] + list(df["Region"].unique()))
category = st.selectbox("Select Category", options=["All"] + list(df["Category"].unique()))

filtered_df = df.copy()
if region != "All":
    filtered_df = filtered_df[filtered_df["Region"] == region]
if category != "All":
    filtered_df = filtered_df[filtered_df["Category"] == category]

# Revenue over time
fig = px.line(filtered_df, x="Date", y="Revenue", title="Revenue Over Time", markers=True)
st.plotly_chart(fig)

# Category-wise bar chart
fig2 = px.bar(filtered_df, x="Category", y="Revenue", color="Category", title="Revenue by Category")
st.plotly_chart(fig2)