# Sales Dashboard

This is a simple interactive sales dashboard built using Streamlit and Plotly.

## Features
- Filter by region and product category
- View revenue trends over time
- Explore category-wise sales performance

## How to Run
1. Install required packages:
```
pip install streamlit plotly pandas
```
2. Run the app:
```
streamlit run app.py
```

## Demo
This dashboard is useful for small businesses or students learning data analysis.

---

Built by Teesha Patel 🌟